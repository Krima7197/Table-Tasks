//
//  tblcustcell2.swift
//  TableViewWithCollectionView
//
//  Created by TOPS on 9/7/18.
//  Copyright © 2018 TOPS. All rights reserved.
//

import UIKit

class tblcustcell2: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    @IBOutlet weak var collview: UICollectionView!
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
