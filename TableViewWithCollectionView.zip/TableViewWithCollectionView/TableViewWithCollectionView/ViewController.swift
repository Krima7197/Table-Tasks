
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,UICollectionViewDelegate,UICollectionViewDataSource
{
    let banner = ["1011.png","calender.png","phone.jpeg"]
    let collarr = ["mail.jpeg","pass.jpeg","user.png","pass.jpeg","user.png","pass.jpeg","user.png"]
    
    
    override func viewDidLoad()
    {
        super.viewDidLoad()
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return banner.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        if indexPath.row == 0
        {   let cell = tableView.dequeueReusableCell(withIdentifier: "tblcell1", for: indexPath) as! tblcustcell1
            cell.img1.image = UIImage(named: banner[0])
            return cell
        }
        else if indexPath.row == 1
        {   let cell = tableView.dequeueReusableCell(withIdentifier: "tblcell2", for: indexPath) as! tblcustcell2
            cell.collview.reloadData()
            return cell
        }
        else
        {   let cell = tableView.dequeueReusableCell(withIdentifier: "tblcell1", for: indexPath) as!  tblcustcell1
           cell.img1.image = UIImage(named: banner[1])
            return  cell
        }
    }
    
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return collarr.count
    }

    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell =  collectionView.dequeueReusableCell(withReuseIdentifier: "collcell", for: indexPath) as! collcustcell
        cell.img2.image = UIImage(named: collarr[indexPath.row])
        return cell
    }
    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
    }


}

