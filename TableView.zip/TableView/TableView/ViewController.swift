
import UIKit

class ViewController: UIViewController,UITableViewDataSource,UITableViewDelegate,CAAnimationDelegate {
    @IBOutlet weak var tbl: UITableView!
    
    //var arr=["ios","iphone","macos","ipad"]
    var arr=["1","2","3","4"]
    //var imgarr=["taxi_logos_PNG17.png","IMGLaunchScreen.png","invitation.png","1011.png"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.navigationItem.leftBarButtonItem = editButtonItem
        let item = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(self.add))
        self.navigationItem.rightBarButtonItem = item
        
        /*let tbl = UITableView(frame: self.view.bounds, style: .grouped)
        tbl.dataSource = self
        tbl.delegate = self
        self.view.addSubview(tbl)*/
        
        /*let left=UISwipeGestureRecognizer(target: self, action: #selector(self.test))
        self.view.isUserInteractionEnabled=true
        left.direction  = .left
        self.view.addGestureRecognizer(left)*/
    }
    
    func add(sender:UIBarButtonItem)
    {
        let indexpath = IndexPath(row: 0, section: 0)
        let cnt = "\(arr.count + 1)"
        arr.insert(cnt, at: 0)
        tbl.insertRows(at: [indexpath], with: UITableViewRowAnimation.fade)
    }
    override func setEditing(_ editing: Bool, animated: Bool) {
        tbl.setEditing(editing, animated: animated)
        super.setEditing(editing, animated: animated)
    }
   /* func test(sender:UISwipeGestureRecognizer)
    {
        let info = UITableViewRowAction(style: .default, title: "Info") { (action, index) in
            print("Information...")
            
        }
    }*/
    
    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell
    {
        
        //tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell=tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! custCell
        cell.lbl.text =  arr[indexPath.row]
        //cell.img.image = UIImage(named: imgarr[indexPath.row])
        cell.btn.addTarget(self, action: #selector(self.test), for: .touchUpInside)
        cell.btn.tag = indexPath.row
        
        //cell.textLabel?.text=arr[indexPath.row]
        //cell.imageView?.image=UIImage(named: imgarr[indexPath.row])
        cell.accessoryType = .disclosureIndicator
        /*let imgview=UIImageView(frame: CGRect(x: 0, y: 0, width: 20, height: 20))
        imgview.image=UIImage(named: imgarr[indexPath.row])
        cell.accessoryView=imgview*/
        return cell
    }
    
    
    func test(sender:UIButton) {
        let index = IndexPath(row: sender.tag, section: 0)
        let cell = tbl.cellForRow(at: index) as! custCell
        print(cell.lbl.text!)
    }
    
    func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCellEditingStyle {
        if indexPath.row==0
        {   return UITableViewCellEditingStyle.none
        }
        else
        {   return UITableViewCellEditingStyle.delete
        }
    }
    
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCellEditingStyle, forRowAt indexPath: IndexPath)
    {
        /*arr.remove(at: indexPath.row)
        tableView.reloadData()*/
        arr.remove(at: indexPath.row)
        tableView.deleteRows(at: [indexPath], with: UITableViewRowAnimation.middle)
        
    }
    
    
    func tableView(_ tableView: UITableView, accessoryButtonTappedForRowWith indexPath: IndexPath) {
        print(indexPath.row)
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print(arr[indexPath.row])
    }
    
    /*func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }
    
    func tableView(_ tableView: UITableView, heightForFooterInSection section: Int) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, heightForHeaderInSection section: Int) -> CGFloat {
        return 100
    }
    func tableView(_ tableView: UITableView, titleForFooterInSection section: Int) -> String? {
        return "Information"
    }
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return "Over"
    }
    func tableView(_ tableView: UITableView, viewForFooterInSection section: Int) -> UIView? {
        let v1 = UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100))
        v1.backgroundColor=UIColor.gray
        return v1
    }
    func tableView(_ tableView: UITableView, viewForHeaderInSection section: Int) -> UIView? {
        let v1=UIView(frame: CGRect(x: 0, y: 0, width: tableView.frame.size.width, height: 100))
        v1.backgroundColor = UIColor.black
        return v1
    }*/
    
    /*func tableView(_ tableView: UITableView, editActionsForRowAt indexPath: IndexPath) -> [UITableViewRowAction]? {
        let ok=UITableViewRowAction(style: .default, title: "OK") { (action, index) in
        
        }
        let cancel=UITableViewRowAction(style: .destructive, title: "Cancel") { (action, index) in
            
        }
        return [ok,cancel]
    }*/
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

