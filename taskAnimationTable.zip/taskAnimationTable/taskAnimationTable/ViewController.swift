
import UIKit

class ViewController: UIViewController,UITableViewDelegate,UITableViewDataSource,CAAnimationDelegate {

    
    var arr = ["121","212","312","4123"]
    var txt = UITextField()
    var tbl = UITableView()
    override func viewDidLoad()
    {
        super.viewDidLoad()
        txt = UITextField(frame: CGRect(x: 50, y: 50, width: 200, height: 30))
        txt.placeholder = "Select City.."
        txt.addTarget(self, action: #selector(self.add), for: .touchDown)
        tbl = UITableView(frame: CGRect(x:50 , y: 80, width: 200 , height: 0))
        tbl.delegate = self
        tbl.dataSource = self
        self.view.addSubview(tbl)
        self.view.addSubview(txt)
        
    }
    
    
    
    
     func add(sender:UITextField)
    {
        print("click")
        
       UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 50, y: 80, width: 200, height: 200)
        UIView.commitAnimations()
        tbl.reloadData()
    }

    
    func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return arr.count
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        txt.text = arr[indexPath.row]
        UIView.beginAnimations(nil, context: nil)
        UIView.setAnimationDuration(0.5)
        UIView.setAnimationDelegate(self)
        tbl.frame = CGRect(x: 50, y: 80, width: 200, height: 0)
        UIView.commitAnimations()

    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        tableView.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        cell.textLabel?.text = arr[indexPath.row]
        return cell
        
    }

    
    
    override func didReceiveMemoryWarning()
    {
        super.didReceiveMemoryWarning()
       
    }
}

